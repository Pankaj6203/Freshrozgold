<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;

class KycController extends Controller
{
    /**
     * Verify PAN Card
     * No OTP required - Direct verification
     */
    public function verifyPan(Request $request)
    {
        try {
            // Validate input
            $validator = Validator::make($request->all(), [
                'mobile' => 'required|digits:10|regex:/^[6-9]\d{9}$/',
                'pan_number' => 'required|regex:/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid input. Please check PAN number format (ABCDE1234F) and mobile number.',
                    'errors' => $validator->errors(),
                    'timestamp' => now()
                ], 400);
            }

            $mobile = $request->mobile;
            $panNumber = strtoupper($request->pan_number);

            // Check if PAN already verified
            $existingPan = DB::table('pan_verifications')
                ->where('pan_number', $panNumber)
                ->where('is_verified', true)
                ->first();

            if ($existingPan) {
                return response()->json([
                    'success' => true,
                    'message' => 'PAN already verified',
                    'data' => [
                        'pan_number' => $panNumber,
                        'name' => $existingPan->name,
                        'status' => $existingPan->status,
                        'verified_at' => $existingPan->verified_at,
                        'already_verified' => true
                    ],
                    'timestamp' => now()
                ], 200);
            }

            // Call PAN Verification API
            $apiResult = $this->callPanVerificationAPI($panNumber);

            if (!$apiResult['success']) {
                return response()->json([
                    'success' => false,
                    'message' => 'PAN verification failed: ' . ($apiResult['error'] ?? 'Unknown error'),
                    'timestamp' => now()
                ], 400);
            }

            // Store PAN verification data
            $verificationId = 'PAN_' . time() . '_' . rand(1000, 9999);
            
            DB::table('pan_verifications')->insert([
                'mobile' => $mobile,
                'pan_number' => $panNumber,
                'name' => $apiResult['data']['name'] ?? null,
                'name_on_card' => $apiResult['data']['name_on_card'] ?? null,
                'father_name' => $apiResult['data']['father_name'] ?? null,
                'date_of_birth' => $apiResult['data']['date_of_birth'] ?? null,
                'status' => $apiResult['data']['status'] ?? 'valid',
                'category' => $apiResult['data']['category'] ?? null,
                'is_verified' => true,
                'verification_id' => $verificationId,
                'masked_image_url' => $apiResult['data']['masked_image'] ?? null,
                'api_response' => json_encode($apiResult['raw_response']),
                'verified_at' => now(),
                'created_at' => now(),
                'updated_at' => now()
            ]);

            Log::info("PAN Verified Successfully - PAN: $panNumber, Mobile: $mobile");

            return response()->json([
                'success' => true,
                'message' => 'PAN verified successfully',
                'data' => [
                    'verification_id' => $verificationId,
                    'pan_number' => $panNumber,
                    'name' => $apiResult['data']['name'],
                    'name_on_card' => $apiResult['data']['name_on_card'] ?? null,
                    'status' => $apiResult['data']['status'],
                    'category' => $apiResult['data']['category'] ?? 'individual',
                    'verified_at' => now()
                ],
                'timestamp' => now()
            ], 200);

        } catch (\Exception $e) {
            Log::error("PAN Verification Error: " . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'message' => 'Internal server error',
                'timestamp' => now()
            ], 500);
        }
    }

    /**
     * Generate Aadhaar OTP
     */
    public function aadhaarGenerateOtp(Request $request)
    {
        try {
            // Validate input
            $validator = Validator::make($request->all(), [
                'mobile' => 'required|digits:10|regex:/^[6-9]\d{9}$/',
                'aadhaar_number' => 'required|digits:12'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid input. Aadhaar must be 12 digits.',
                    'errors' => $validator->errors(),
                    'timestamp' => now()
                ], 400);
            }

            $mobile = $request->mobile;
            $aadhaarNumber = $request->aadhaar_number;

            // Call Aadhaar OTP Generation API
            $apiResult = $this->callAadhaarOtpAPI($aadhaarNumber);

            if (!$apiResult['success']) {
                return response()->json([
                    'success' => false,
                    'message' => 'Failed to generate Aadhaar OTP: ' . ($apiResult['error'] ?? 'Unknown error'),
                    'timestamp' => now()
                ], 400);
            }

            // Store request for verification later
            $requestId = $apiResult['data']['request_id'];
            
            // Ensure request_id is string format for consistency
            $formattedRequestId = is_numeric($requestId) ? (string)$requestId : $requestId;
            
            DB::table('aadhaar_verifications')->insert([
                'mobile' => $mobile,
                'aadhaar_number' => $aadhaarNumber,
                'request_id' => $formattedRequestId,
                'is_verified' => false,
                'created_at' => now(),
                'updated_at' => now()
            ]);

            Log::info("Aadhaar OTP Generated - Aadhaar: $aadhaarNumber, RequestID: $formattedRequestId");

            return response()->json([
                'success' => true,
                'message' => 'OTP sent to Aadhaar registered mobile number',
                'data' => [
                    'request_id' => $formattedRequestId,  // String format
                    'aadhaar_number' => 'XXXX XXXX ' . substr($aadhaarNumber, -4),
                    'message' => 'OTP sent to registered mobile number'
                ],
                'timestamp' => now()
            ], 200);

        } catch (\Exception $e) {
            Log::error("Aadhaar OTP Generation Error: " . $e->getMessage());
            Log::error("Stack Trace: " . $e->getTraceAsString());
            
            return response()->json([
                'success' => false,
                'message' => 'Internal server error: ' . $e->getMessage(),
                'timestamp' => now()
            ], 500);
        }
    }

    /**
     * Verify Aadhaar OTP and get details
     */
    public function aadhaarVerifyOtp(Request $request)
    {
        try {
            // Validate input
            $validator = Validator::make($request->all(), [
                'request_id' => 'required|string',
                'otp' => 'required|digits:6'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid input. OTP must be 6 digits.',
                    'errors' => $validator->errors(),
                    'timestamp' => now()
                ], 400);
            }

            $requestId = $request->request_id;
            $otp = $request->otp;
            
            Log::info("Aadhaar Verify OTP Request - RequestID: $requestId, OTP: $otp");

            // Find pending verification
            $pendingVerification = DB::table('aadhaar_verifications')
                ->where('request_id', $requestId)
                ->where('is_verified', false)
                ->orderBy('created_at', 'desc')
                ->first();
            
            Log::info("Pending Verification Found: " . ($pendingVerification ? 'Yes (ID: ' . $pendingVerification->id . ')' : 'No'));

            if (!$pendingVerification) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid or expired request ID',
                    'timestamp' => now()
                ], 400);
            }

            // Call Aadhaar Verification API
            $apiResult = $this->callAadhaarVerifyAPI($requestId, $otp);

            if (!$apiResult['success']) {
                return response()->json([
                    'success' => false,
                    'message' => 'Aadhaar verification failed: ' . ($apiResult['error'] ?? 'Invalid OTP'),
                    'timestamp' => now()
                ], 400);
            }

            // Update verification record with Aadhaar details
            $verificationId = 'AADHAAR_' . time() . '_' . rand(1000, 9999);
            
            DB::table('aadhaar_verifications')
                ->where('id', $pendingVerification->id)
                ->update([
                    'name' => $apiResult['data']['name'] ?? null,
                    'father_name' => $apiResult['data']['father_name'] ?? null,
                    'address' => $apiResult['data']['address'] ?? null,
                    'city' => $apiResult['data']['city'] ?? null,
                    'state' => $apiResult['data']['state'] ?? null,
                    'pincode' => $apiResult['data']['pincode'] ?? null,
                    'date_of_birth' => $apiResult['data']['date_of_birth'] ?? null,
                    'gender' => $apiResult['data']['gender'] ?? null,
                    'email' => $apiResult['data']['email'] ?? null,
                    'phone' => $apiResult['data']['phone'] ?? null,
                    'masked_aadhaar_image' => $apiResult['data']['masked_image'] ?? null,
                    'profile_image' => $apiResult['data']['profile_image'] ?? null,
                    'is_verified' => true,
                    'verification_id' => $verificationId,
                    'api_response' => json_encode($apiResult['raw_response']),
                    'verified_at' => now(),
                    'updated_at' => now()
                ]);

            Log::info("Aadhaar Verified Successfully - RequestID: $requestId, VerificationID: $verificationId");

            return response()->json([
                'success' => true,
                'message' => 'Aadhaar verified successfully',
                'data' => [
                    'verification_id' => $verificationId,
                    'name' => $apiResult['data']['name'],
                    'father_name' => $apiResult['data']['father_name'] ?? null,
                    'date_of_birth' => $apiResult['data']['date_of_birth'] ?? null,
                    'gender' => $apiResult['data']['gender'] ?? null,
                    'address' => $apiResult['data']['address'] ?? null,
                    'city' => $apiResult['data']['city'] ?? null,
                    'state' => $apiResult['data']['state'] ?? null,
                    'pincode' => $apiResult['data']['pincode'] ?? null,
                    'masked_aadhaar_number' => 'XXXX XXXX ' . substr($pendingVerification->aadhaar_number, -4),
                    'masked_image' => $apiResult['data']['masked_image'] ?? null,
                    'profile_image' => $apiResult['data']['profile_image'] ?? null,
                    'verified_at' => now()
                ],
                'timestamp' => now()
            ], 200);

        } catch (\Exception $e) {
            Log::error("Aadhaar Verification Error: " . $e->getMessage());
            Log::error("Stack Trace: " . $e->getTraceAsString());
            
            return response()->json([
                'success' => false,
                'message' => 'Internal server error: ' . $e->getMessage(),
                'timestamp' => now()
            ], 500);
        }
    }

    /**
     * Call PAN Verification API
     */
    private function callPanVerificationAPI($panNumber)
    {
        try {
            // Get API credentials from environment - Use production key
            $apiKey = env('KYC_API_KEY', '4a62c059-7b61-4491-a38f-89d3462b1005');
            $apiUrl = env('KYC_API_URL', 'https://api.quickekyc.com');
            
            Log::info("PAN API Call - PAN: $panNumber, API Key: " . substr($apiKey, 0, 8) . "...");

            // Initialize cURL for QuickeKYC API
            $ch = curl_init();
            
            curl_setopt_array($ch, [
                CURLOPT_URL => $apiUrl . '/api/v1/pan/pan',  // Correct QuickeKYC endpoint
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => json_encode([
                    'key' => $apiKey,
                    'id_number' => $panNumber  // QuickeKYC uses 'id_number' parameter
                ]),
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json'
                ],
                CURLOPT_SSL_VERIFYPEER => false,  // For sandbox testing
                CURLOPT_SSL_VERIFYHOST => 0
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            
            if (curl_errno($ch)) {
                $error = curl_error($ch);
                curl_close($ch);
                throw new \Exception('cURL Error: ' . $error);
            }
            
            curl_close($ch);

            Log::info("PAN API Response - HTTP: $httpCode");
            Log::info("PAN API Response Body: " . $response);

            $result = json_decode($response, true);

            // Handle QuickeKYC response format
            if ($httpCode === 200 && isset($result['status'])) {
                if ($result['status'] === 'success' && isset($result['data'])) {
                    $data = $result['data'];
                    
                    return [
                        'success' => true,
                        'data' => [
                            'name' => $data['full_name'] ?? $data['name'] ?? null,
                            'name_on_card' => $data['name_on_card'] ?? $data['full_name'] ?? null,
                            'father_name' => $data['fathers_name'] ?? $data['father_name'] ?? null,
                            'date_of_birth' => $data['dob'] ?? $data['date_of_birth'] ?? null,
                            'status' => 'valid',
                            'category' => $data['category'] ?? 'individual',
                            'masked_image' => $data['masked_pan_image'] ?? $data['masked_image'] ?? null
                        ],
                        'raw_response' => $result
                    ];
                } elseif ($result['status'] === 'error' || $result['status'] === 'failed') {
                    return [
                        'success' => false,
                        'error' => $result['message'] ?? 'PAN verification failed'
                    ];
                }
            }

            return [
                'success' => false,
                'error' => $result['message'] ?? 'Invalid API response'
            ];

        } catch (\Exception $e) {
            Log::error("PAN API Error: " . $e->getMessage());
            
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Call Aadhaar OTP Generation API
     */
    private function callAadhaarOtpAPI($aadhaarNumber)
    {
        try {
            $environment = env('KYC_ENVIRONMENT', 'production');
            $apiKey = $environment === 'sandbox' 
                ? env('KYC_SANDBOX_API_KEY') 
                : env('KYC_API_KEY');
            $apiUrl = $environment === 'sandbox'
                ? env('KYC_SANDBOX_URL', 'https://sandbox.quickekyc.com')
                : env('KYC_API_URL', 'https://api.quickekyc.com');
            
            Log::info("Aadhaar OTP API - Environment: $environment, URL: $apiUrl, API Key: " . substr($apiKey, 0, 8) . "...");
            
            // For testing without real API key - Mock response
            if (!$apiKey || $apiKey === 'your_kyc_api_key_here') {
                Log::info("Aadhaar OTP API - Using MOCK response for testing");
                
                sleep(1);
                
                return [
                    'success' => true,
                    'data' => [
                        'request_id' => 'MOCK_REQ_' . time() . '_' . rand(1000, 9999)
                    ],
                    'raw_response' => [
                        'status' => 'success',
                        'message' => 'OTP sent successfully (MOCK MODE - For testing only)',
                        'mock_mode' => true
                    ]
                ];
            }
            
            Log::info("Aadhaar OTP API Call - Aadhaar: ****" . substr($aadhaarNumber, -4));

            $ch = curl_init();
            
            curl_setopt_array($ch, [
                CURLOPT_URL => $apiUrl . '/api/v1/aadhaar-v2/generate-otp',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => json_encode([
                    'key' => $apiKey,
                    'id_number' => $aadhaarNumber
                ]),
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json'
                ],
                CURLOPT_SSL_VERIFYPEER => env('KYC_ENVIRONMENT') === 'production',
                CURLOPT_SSL_VERIFYHOST => env('KYC_ENVIRONMENT') === 'production' ? 2 : 0
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            
            if (curl_errno($ch)) {
                throw new \Exception('cURL Error: ' . curl_error($ch));
            }
            
            curl_close($ch);

            Log::info("Aadhaar OTP API Response - HTTP: $httpCode");
            Log::info("Aadhaar OTP API Raw Response: " . substr($response, 0, 500));

            $result = json_decode($response, true);

            if ($httpCode === 200 && isset($result['status']) && $result['status'] === 'success') {
                // Get request_id from API - it returns as integer or string
                $apiRequestId = $result['data']['request_id'] ?? $result['request_id'] ?? null;
                
                // Convert to string if it's numeric to ensure consistent format
                $requestId = $apiRequestId !== null ? (string)$apiRequestId : 'REQ_' . time() . '_' . rand(1000, 9999);
                
                Log::info("Aadhaar OTP Generated Successfully - RequestID: " . $requestId);
                return [
                    'success' => true,
                    'data' => [
                        'request_id' => $requestId
                    ],
                    'raw_response' => $result
                ];
            }

            Log::warning("Aadhaar OTP Generation Failed - HTTP: $httpCode, Message: " . ($result['message'] ?? 'no message'));
            return [
                'success' => false,
                'error' => $result['message'] ?? 'Failed to generate OTP'
            ];

        } catch (\Exception $e) {
            Log::error("Aadhaar OTP API Error: " . $e->getMessage());
            
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Call Aadhaar Verification API
     */
    private function callAadhaarVerifyAPI($requestId, $otp)
    {
        try {
            $apiKey = env('KYC_API_KEY');
            $apiUrl = env('KYC_API_URL', 'https://api.quickekyc.com');
            
            Log::info("Aadhaar Verify API Call - RequestID: $requestId");

            $ch = curl_init();
            
            curl_setopt_array($ch, [
                CURLOPT_URL => $apiUrl . '/api/v1/aadhaar-v2/submit-otp',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => json_encode([
                    'key' => $apiKey,
                    'request_id' => $requestId,
                    'otp' => $otp
                ]),
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json'
                ],
                CURLOPT_SSL_VERIFYPEER => env('KYC_ENVIRONMENT') === 'production',
                CURLOPT_SSL_VERIFYHOST => env('KYC_ENVIRONMENT') === 'production' ? 2 : 0
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            
            if (curl_errno($ch)) {
                throw new \Exception('cURL Error: ' . curl_error($ch));
            }
            
            curl_close($ch);

            Log::info("Aadhaar Verify API Response - HTTP: $httpCode");
            Log::info("Aadhaar Verify API Raw Response: " . $response);

            $result = json_decode($response, true);

            if ($httpCode === 200 && isset($result['status']) && $result['status'] === 'success') {
                $data = $result['data'] ?? [];
                
                // Map gender from API format to database enum format
                $genderMap = [
                    'M' => 'male',
                    'F' => 'female',
                    'MALE' => 'male',
                    'FEMALE' => 'female',
                    'male' => 'male',
                    'female' => 'female',
                    'other' => 'other'
                ];
                $apiGender = strtoupper($data['gender'] ?? 'OTHER');
                $gender = $genderMap[$apiGender] ?? 'other';
                
                // Handle address - could be string or array
                $address = $data['address'] ?? $data['full_address'] ?? null;
                if (is_array($address)) {
                    // Convert address array to readable string
                    $addressParts = [];
                    if (!empty($address['house'])) $addressParts[] = $address['house'];
                    if (!empty($address['street'])) $addressParts[] = $address['street'];
                    if (!empty($address['landmark'])) $addressParts[] = $address['landmark'];
                    if (!empty($address['loc'])) $addressParts[] = $address['loc'];
                    if (!empty($address['vtc'])) $addressParts[] = $address['vtc'];
                    if (!empty($address['po'])) $addressParts[] = $address['po'];
                    if (!empty($address['dist'])) $addressParts[] = $address['dist'];
                    if (!empty($address['subdist'])) $addressParts[] = $address['subdist'];
                    if (!empty($address['state'])) $addressParts[] = $address['state'];
                    if (!empty($address['country'])) $addressParts[] = $address['country'];
                    $address = implode(', ', $addressParts);
                }
                
                return [
                    'success' => true,
                    'data' => [
                        'name' => $data['name'] ?? $data['full_name'] ?? null,
                        'father_name' => $data['father_name'] ?? $data['care_of'] ?? null,
                        'date_of_birth' => $data['dob'] ?? $data['date_of_birth'] ?? null,
                        'gender' => $gender,
                        'address' => $data['address'] ?? $data['full_address'] ?? null,
                        'city' => $data['city'] ?? $data['district'] ?? null,
                        'state' => $data['state'] ?? null,
                        'pincode' => $data['pincode'] ?? $data['zip'] ?? null,
                        'email' => $data['email'] ?? null,
                        'phone' => $data['phone'] ?? $data['mobile'] ?? null,
                        'masked_image' => $data['masked_aadhaar'] ?? $data['aadhaar_pdf'] ?? null,
                        'profile_image' => $data['photo'] ?? $data['profile_image'] ?? null
                    ],
                    'raw_response' => $result
                ];
            }

            Log::warning("Aadhaar Verify API Failed - Status: " . ($result['status'] ?? 'unknown') . ", Message: " . ($result['message'] ?? 'no message'));
            
            return [
                'success' => false,
                'error' => $result['message'] ?? 'Invalid OTP or verification failed'
            ];

        } catch (\Exception $e) {
            Log::error("Aadhaar Verify API Error: " . $e->getMessage());
            
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
}

