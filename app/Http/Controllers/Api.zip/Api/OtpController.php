<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;

class OtpController extends Controller
{
    /**
     * Send OTP to mobiles number
     */
    public function sendOtp(Request $request)
    {
        try {
            // Validate input
            $validator = Validator::make($request->all(), [
                'mobiles' => 'required|digits:10|regex:/^[6-9]\d{9}$/'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid mobiles number format. Please enter a 10-digit mobiles number.',
                    'errors' => $validator->errors(),
                    'timestamp' => now()
                ], 400);
            }

            $mobiles = $request->mobiles;

            // Generate OTP (configurable length from env)
            $otpLength = (int) env('OTP_LENGTH', 6);
            $maxOtpValue = (int) str_repeat('9', $otpLength);
            $otp = str_pad(random_int(0, $maxOtpValue), $otpLength, '0', STR_PAD_LEFT);

            // Calculate expiry time (configurable from env)
            $otpValidityMinutes = (int) env('OTP_VALIDITY_MINUTES', 10);
            $expiresAt = Carbon::now()->addMinutes($otpValidityMinutes);

            // Expire any previous unverified OTPs for this mobiles
            DB::table('otps')
                ->where('mobiles', $mobiles)
                ->where('is_verified', false)
                ->update(['is_verified' => true]);

            // Store OTP in database
            DB::table('otps')->insert([
                'mobiles' => $mobiles,
                'otp' => $otp,
                'expires_at' => $expiresAt,
                'is_verified' => false,
                'created_at' => now(),
                'updated_at' => now()
            ]);

            // Send OTP via SMS
            $smsResult = $this->sendOtpSms($mobiles, $otp);

            if (!$smsResult['success']) {
                $errorMessage = $smsResult['error'] ?? 'SMS service unavailable';
                Log::error("OTP Send Failed - mobiles: $mobiles, Error: $errorMessage");
                Log::error("SMS Result: " . json_encode($smsResult));
                
                return response()->json([
                    'success' => false,
                    'message' => 'Failed to send OTP: ' . $errorMessage,
                    'debug' => config('app.debug') ? $smsResult : null,
                    'timestamp' => now()
                ], 500);
            }

            // Prepare response
            $otpValidityMinutes = (int) env('OTP_VALIDITY_MINUTES', 10);
            $responseData = [
                'mobiles' => $mobiles,
                'expires_in' => $otpValidityMinutes * 60 // Convert minutes to seconds
            ];

            // In development mode, include OTP in response
            if (config('app.debug')) {
                $responseData['otp'] = $otp;
                $responseData['dev_mode'] = true;
            }

            return response()->json([
                'success' => true,
                'message' => 'OTP sent successfully',
                'data' => $responseData,
                'timestamp' => now()
            ], 200);

        } catch (\Exception $e) {
            Log::error("Send OTP Error: " . $e->getMessage());
            Log::error("Stack Trace: " . $e->getTraceAsString());
            
            return response()->json([
                'success' => false,
                'message' => 'Internal server error',
                'error' => config('app.debug') ? $e->getMessage() : null,
                'timestamp' => now()
            ], 500);
        }
    }

    /**
     * Verify OTP
     */
    public function verifyOtp(Request $request)
    {
        try {
            // Validate input
            $otpLength = (int) env('OTP_LENGTH', 6);
            $validator = Validator::make($request->all(), [
                'mobiles' => 'required|digits:10|regex:/^[6-9]\d{9}$/',
                'otp' => "required|digits:{$otpLength}"
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Missing or invalid required fields',
                    'errors' => $validator->errors(),
                    'timestamp' => now()
                ], 400);
            }

            $mobiles = $request->mobiles;
            $otp = $request->otp;

            // Verify OTP from database
            $otpRecord = DB::table('otps')
                ->where('mobiles', $mobiles)
                ->where('otp', $otp)
                ->where('expires_at', '>', now())
                ->where('is_verified', false)
                ->orderBy('created_at', 'desc')
                ->first();

            if (!$otpRecord) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid or expired OTP',
                    'timestamp' => now()
                ], 400);
            }

            // Mark OTP as verified
            DB::table('otps')
                ->where('id', $otpRecord->id)
                ->update(['is_verified' => true, 'updated_at' => now()]);

            // Log successful verification
            Log::info("OTP verified successfully for mobiles: $mobiles");

            return response()->json([
                'success' => true,
                'message' => 'OTP verified successfully',
                'data' => [
                    'mobiles' => $mobiles,
                    'verified_at' => now()
                ],
                'timestamp' => now()
            ], 200);

        } catch (\Exception $e) {
            Log::error("Verify OTP Error: " . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'message' => 'Internal server error',
                'timestamp' => now()
            ], 500);
        }
    }

    /**
     * Send OTP via SMS (SMSMenow Integration)
     */
    private function sendOtpSms($mobiles, $otp)
    {
        try {
            // SMS configuration - Use environment variables
            $smsmenowUser = env('SMSMENOW_USER', 'rozgold');
            $smsmenowPassword = env('SMSMENOW_PASSWORD', '6007b0a6c2XX');
            $smsmenowSenderId = env('SMSMENOW_SENDERID', 'ROZGLD');
            $smsmenowUrl = env('SMSMENOW_URL', 'http://sms.smsmenow.in/sendsms.jsp');
            $jsessionId = env('SMSMENOW_JSESSIONID', '039173125348E90D79475DE345B52C29');
            
            // Log SMS attempt with all details
            Log::info("=== SMS SEND START ===");
            Log::info("SMS Send Attempt - mobile: $mobiles, User: $smsmenowUser, OTP: $otp");
            Log::info("SMS URL: $smsmenowUrl");

            // Check if cURL is available
            if (!function_exists('curl_init')) {
                Log::error("cURL is not installed or enabled on this server!");
                throw new \Exception('cURL extension is not available');
            }

            // Format mobiles number
            $formattedMobiles = $mobiles;
            if (!str_starts_with($mobiles, '+')) {
                if (strlen($mobiles) === 10 && preg_match('/^[6-9]\d{9}$/', $mobiles)) {
                    $formattedMobiles = '+91' . $mobiles;
                }
            }
            Log::info("Formatted mobiles: $formattedMobiles");

            // Create SMS message (configurable from env)
            $otpValidityMinutes = (int) env('OTP_VALIDITY_MINUTES', 10);
            $smsTemplate = env('SMS_TEMPLATE', "Your OTP is {otp} for RozGold verification. It is Valid for {validity} minutes only. Do not share this OTP with anyone. www.rozgold.in");
            $message = str_replace(['{otp}', '{validity}'], [$otp, $otpValidityMinutes], $smsTemplate);
            
            Log::info("SMS Message: $message");

            // Initialize cURL
            $ch = curl_init();
            
            if ($ch === false) {
                Log::error("Failed to initialize cURL!");
                throw new \Exception('Failed to initialize cURL');
            }

            // Build the URL with parameters - exactly as per working curl command
            $url = $smsmenowUrl . '?' . http_build_query([
                'user'      => $smsmenowUser,
                'password'  => $smsmenowPassword,
                'senderid'  => $smsmenowSenderId,
                'mobiles'   => $formattedMobiles,
                'sms'       => $message,
            ]);
                   
            Log::info("Full SMS URL (masked password): " . preg_replace('/password=[^&]*/', 'password=****', $url));

            // Set cURL options - match working curl command (POST with empty body, no Cookie)
            curl_setopt_array($ch, [
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => '', // Empty POST body as per working curl
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_CONNECTTIMEOUT => 10,
            ]);

            Log::info("cURL initialized, executing request...");

            // Execute the request
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            $curlErrno = curl_errno($ch);

            Log::info("cURL executed - HTTP Code: $httpCode, Error No: $curlErrno");

            if ($curlErrno !== 0) {
                Log::error("cURL Error #$curlErrno: $curlError");
                curl_close($ch);
                throw new \Exception("cURL Error #$curlErrno: $curlError");
            }

            curl_close($ch);

            // Log the response
            Log::info("SMSMenow API Raw Response: " . ($response ?: 'EMPTY RESPONSE'));
            Log::info("SMSMenow HTTP Code: " . $httpCode);

            // Also log locally for development
            $this->logOtpLocally($mobiles, $otp);

            // Check for success response
            if ($httpCode == 200 && $response && strpos($response, '<status>success</status>') !== false) {
                Log::info("✓ SMS Sent Successfully - mobiles: $mobiles");
                Log::info("=== SMS SEND END (SUCCESS) ===");
                return [
                    'success' => true,
                    'message_id' => time(),
                    'status' => 'sent',
                    'message' => 'OTP sent successfully via SMS'
                ];
            } else {
                Log::error("✗ SMSMenow SMS Failed - HTTP: $httpCode");
                Log::error("Response: " . ($response ?: 'NO RESPONSE'));
                Log::error("=== SMS SEND END (FAILED) ===");
                
                return [
                    'success' => false,
                    'error' => 'SMS service failed: ' . substr($response ?: 'No response from SMS gateway', 0, 100),
                    'http_code' => $httpCode,
                    'fallback' => 'OTP logged locally due to SMS failure'
                ];
            }

        } catch (\Exception $e) {
            Log::error("✗ SMSMenow SMS Exception: " . $e->getMessage());
            Log::error("Exception Trace: " . $e->getTraceAsString());
            Log::error("=== SMS SEND END (EXCEPTION) ===");
            
            // Fallback to local logging
            $this->logOtpLocally($mobiles, $otp);
            
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'fallback' => 'OTP logged locally due to SMS failure'
            ];
        }
    }

    /**
     * Resend OTP to mobiles number (with 2-minute cooldown)
     */
    public function resendOtp(Request $request)
    {
        try {
            // Validate input
            $validator = Validator::make($request->all(), [
                'mobiles' => 'required|digits:10|regex:/^[6-9]\d{9}$/'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid mobiles number format. Please enter a 10-digit mobiles number.',
                    'errors' => $validator->errors(),
                    'timestamp' => now()
                ], 400);
            }

            $mobiles = $request->mobiles;

            // Check last OTP sent time (2-minute cooldown)
            $lastOtp = DB::table('otps')
                ->where('mobiles', $mobiles)
                ->orderBy('created_at', 'desc')
                ->first();

            if ($lastOtp) {
                $lastOtpTime = Carbon::parse($lastOtp->created_at);
                $timeDifference = now()->diffInSeconds($lastOtpTime);
                $cooldownPeriod = (int) env('OTP_RESEND_COOLDOWN_SECONDS', 120); // Configurable cooldown

                if ($timeDifference < $cooldownPeriod) {
                    $remainingTime = $cooldownPeriod - $timeDifference;
                    $minutes = floor($remainingTime / 60);
                    $seconds = $remainingTime % 60;

                    return response()->json([
                        'success' => false,
                        'message' => "Please wait before requesting a new OTP. Time remaining: {$minutes}m {$seconds}s",
                        'data' => [
                            'remaining_seconds' => $remainingTime,
                            'can_resend_at' => $lastOtpTime->addSeconds($cooldownPeriod)
                        ],
                        'timestamp' => now()
                    ], 429);
                }
            }

            // Generate new OTP (configurable length from env)
            $otpLength = (int) env('OTP_LENGTH', 6);
            $maxOtpValue = (int) str_repeat('9', $otpLength);
            $otp = str_pad(random_int(0, $maxOtpValue), $otpLength, '0', STR_PAD_LEFT);

            // Calculate expiry time (configurable from env)
            $otpValidityMinutes = (int) env('OTP_VALIDITY_MINUTES', 10);
            $expiresAt = Carbon::now()->addMinutes($otpValidityMinutes);

            // Expire any previous unverified OTPs for this mobiles
            DB::table('otps')
                ->where('mobiles', $mobiles)
                ->where('is_verified', false)
                ->update(['is_verified' => true]);

            // Store new OTP in database
            DB::table('otps')->insert([
                'mobiles' => $mobiles,
                'otp' => $otp,
                'expires_at' => $expiresAt,
                'is_verified' => false,
                'created_at' => now(),
                'updated_at' => now()
            ]);

            // Send OTP via SMS
            $smsResult = $this->sendOtpSms($mobiles, $otp);

            if (!$smsResult['success']) {
                Log::error("Resend OTP Failed - mobiles: $mobiles, Error: " . ($smsResult['error'] ?? 'Unknown error'));
                
                return response()->json([
                    'success' => false,
                    'message' => 'Failed to resend OTP: ' . ($smsResult['error'] ?? 'SMS service unavailable'),
                    'timestamp' => now()
                ], 500);
            }

            // Prepare response
            $otpValidityMinutes = (int) env('OTP_VALIDITY_MINUTES', 10);
            $responseData = [
                'mobiles' => $mobiles,
                'expires_in' => $otpValidityMinutes * 60, // Convert minutes to seconds
                'resent_at' => now(),
            ];

            // In development mode, include OTP in response
            if (config('app.debug')) {
                $responseData['otp'] = $otp;
                $responseData['dev_mode'] = true;
            }

            return response()->json([
                'success' => true,
                'message' => 'OTP resent successfully',
                'data' => $responseData,
                'timestamp' => now()
            ], 200);

        } catch (\Exception $e) {
            Log::error("Resend OTP Error: " . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'message' => 'Internal server error',
                'timestamp' => now()
            ], 500);
        }
    }

    /**
     * Log OTP locally for development
     */
    private function logOtpLocally($mobiles, $otp)
    {
        $logMessage = now() . " - OTP for $mobiles: $otp\n";
        $logFile = storage_path('logs/otp_logs.txt');
        
        file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);
        Log::info("GoldApp OTP for $mobiles: $otp");
    }
}
